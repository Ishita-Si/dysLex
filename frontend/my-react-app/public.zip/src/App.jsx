import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AssessmentProvider } from './context/AssessmentContext';
import Layout from './components/common/Layout';

import { LoginPage, RegisterPage, ForgotPasswordPage } from './components/auth/AuthPages';
import Dashboard from './pages/Dashboard';
import { PatientList, PatientProfile } from './pages/Patients';
import { AssessmentShell } from './pages/Assessment';
import ExercisesPage from './pages/Exercises';
import ProgressPage from './pages/Progress';
import { HistoryPage, ReportsPage } from './pages/History';

function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }
  // In demo mode without a backend, allow access without auth
  // Remove this line in production: return user ? children : <Navigate to="/login" replace />;
  return children;
}

function AppRoutes() {
  return (
    <Routes>
      {/* Public */}
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/forgot-password" element={<ForgotPasswordPage />} />

      {/* App */}
      <Route
        path="/*"
        element={
          <ProtectedRoute>
            <AssessmentProvider>
              <Layout>
                <Routes>
                  <Route index element={<Navigate to="/dashboard" replace />} />
                  <Route path="dashboard" element={<Dashboard />} />
                  <Route path="patients" element={<PatientList />} />
                  <Route path="patients/:id" element={<PatientProfile />} />
                  <Route path="assessment/new" element={<AssessmentShell />} />
                  <Route path="exercises" element={<ExercisesPage />} />
                  <Route path="progress" element={<ProgressPage />} />
                  <Route path="history" element={<HistoryPage />} />
                  <Route path="reports" element={<ReportsPage />} />
                  <Route path="*" element={<Navigate to="/dashboard" replace />} />
                </Routes>
              </Layout>
            </AssessmentProvider>
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <AppRoutes />
      </AuthProvider>
    </BrowserRouter>
  );
}